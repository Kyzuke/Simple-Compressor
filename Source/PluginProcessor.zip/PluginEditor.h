/*
  ==============================================================================

    PluginEditor.h
    Interface gr�fica personalizada para o Compressor

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
// LookAndFeel customizado (cores e knobs no estilo "plugin bonito")
class CompressorLookAndFeel : public juce::LookAndFeel_V4
{
public:
    CompressorLookAndFeel()
    {
        using namespace juce;

        // Tema escuro
        setColour(ResizableWindow::backgroundColourId, Colour(0xFF101018));
        setColour(Slider::thumbColourId, Colour(0xFFFFC857)); // amarelo c�trico
        setColour(Slider::rotarySliderFillColourId, Colour(0xFF2D9BF0)); // azul
        setColour(Slider::rotarySliderOutlineColourId, Colour(0xFF0B1C30));
        setColour(Slider::textBoxTextColourId, Colours::white);
        setColour(Slider::textBoxBackgroundColourId, Colour(0xFF121212));
        setColour(Slider::textBoxOutlineColourId, Colours::transparentBlack);
        setColour(Label::textColourId, Colours::white);
    }

    void drawRotarySlider(juce::Graphics& g,
        int x, int y, int width, int height,
        float sliderPosProportional,
        float rotaryStartAngle,
        float rotaryEndAngle,
        juce::Slider& slider) override
    {
        using namespace juce;

        const float radius = (float)juce::jmin(width, height) * 0.45f;
        const float centreX = (float)x + (float)width * 0.5f;
        const float centreY = (float)y + (float)height * 0.5f;
        const float rx = centreX - radius;
        const float ry = centreY - radius;
        const float rw = radius * 2.0f;
        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // Fundo do knob
        g.setColour(Colour(0xFF0F172A));
        g.fillEllipse(rx, ry, rw, rw);

        // Anel externo
        g.setColour(findColour(Slider::rotarySliderOutlineColourId));
        g.drawEllipse(rx, ry, rw, rw, 1.5f);

        // Arco de valor
        {
            Path valueArc;
            valueArc.addCentredArc(centreX, centreY, radius, radius,
                0.0f, rotaryStartAngle, angle, true);

            g.setColour(findColour(Slider::rotarySliderFillColourId));
            g.strokePath(valueArc, PathStrokeType(3.0f, PathStrokeType::curved, PathStrokeType::rounded));
        }

        // Ponteiro
        {
            const float pointerLength = radius * 0.8f;
            const float pointerThickness = 2.0f;

            Path p;
            p.addRectangle(-pointerThickness * 0.5f, -radius, pointerThickness, pointerLength);
            p.applyTransform(AffineTransform::rotation(angle).translated(centreX, centreY));

            g.setColour(findColour(Slider::thumbColourId));
            g.fillPath(p);
        }
    }
};

//==============================================================================

class CompressorAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    CompressorAudioProcessorEditor(CompressorAudioProcessor&);
    ~CompressorAudioProcessorEditor() override;

    //==============================================================================
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    CompressorAudioProcessor& audioProcessor;

    CompressorLookAndFeel lookAndFeel;

    // Sliders dos par�metros
    juce::Slider thresholdSlider;
    juce::Slider ratioSlider;
    juce::Slider attackSlider;
    juce::Slider releaseSlider;
    juce::Slider makeupSlider;

    // Labels
    juce::Label thresholdLabel;
    juce::Label ratioLabel;
    juce::Label attackLabel;
    juce::Label releaseLabel;
    juce::Label makeupLabel;

    // Attachments para ligar com o APVTS
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::unique_ptr<SliderAttachment> thresholdAttachment;
    std::unique_ptr<SliderAttachment> ratioAttachment;
    std::unique_ptr<SliderAttachment> attackAttachment;
    std::unique_ptr<SliderAttachment> releaseAttachment;
    std::unique_ptr<SliderAttachment> makeupAttachment;

    void setupKnob(juce::Slider& slider, juce::Label& label, const juce::String& labelText);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CompressorAudioProcessorEditor)
};
